function x = vec(x)

x.dim = [prod(x.dim) 1];
