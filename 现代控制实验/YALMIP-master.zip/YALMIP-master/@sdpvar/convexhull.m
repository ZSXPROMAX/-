function [A,b] = convexhull(p,xL,xU)

