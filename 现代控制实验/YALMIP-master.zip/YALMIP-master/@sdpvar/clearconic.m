function x = clearconic(x)
x.conicinfo = [0 0];