function sol = minimize(h)

sol = solvesdp([],h);